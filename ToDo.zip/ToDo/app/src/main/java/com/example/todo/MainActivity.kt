package com.example.todo

import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

data class Task(var id: Int, var title: String)

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var taskAdapter: TaskAdapter
    private val tasks = mutableListOf<Task>()
    private var taskIdCounter = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        val fab: FloatingActionButton = findViewById(R.id.Add)

        taskAdapter = TaskAdapter(tasks, ::editTask, ::deleteTask)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = taskAdapter

        fab.setOnClickListener {
            addTask()
        }
    }

    private fun addTask() {
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dailog, null)
        val input = dialogView.findViewById<EditText>(R.id.input)

        AlertDialog.Builder(this)
            .setTitle("Add Task")
            .setView(dialogView)
            .setPositiveButton("Add") { dialog, _ ->
                val taskTitle = input.text.toString()
                if (taskTitle.isNotEmpty()) {
                    val newTask = Task(taskIdCounter++, taskTitle)
                    tasks.add(newTask)
                    taskAdapter.notifyItemInserted(tasks.size - 1)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }
            .show()
    }

    private fun editTask(task: Task) {
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dailog, null)
        val input = dialogView.findViewById<EditText>(R.id.input)
        input.setText(task.title)

        AlertDialog.Builder(this)
            .setTitle("Edit Task")
            .setView(dialogView)
            .setPositiveButton("Update") { dialog, _ ->
                val taskTitle = input.text.toString()
                if (taskTitle.isNotEmpty()) {
                    task.title = taskTitle
                    taskAdapter.notifyItemChanged(tasks.indexOf(task))
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }
            .show()
    }

    private fun deleteTask(task: Task) {
        val position = tasks.indexOf(task)
        tasks.removeAt(position)
        taskAdapter.notifyItemRemoved(position)
    }

    inner class TaskAdapter(
        private val tasks: MutableList<Task>,
        private val onEditClick: (Task) -> Unit,
        private val onDeleteClick: (Task) -> Unit
    ) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
            val itemView = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
            val taskTitle: TextView = itemView.findViewById(R.id.taskTitle)
            val editButton: ImageButton = itemView.findViewById(R.id.editButton)
            val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)
            return TaskViewHolder(itemView, taskTitle, editButton, deleteButton)
        }

        override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
            val task = tasks[position]
            holder.bind(task)
        }

        override fun getItemCount(): Int {
            return tasks.size
        }

        inner class TaskViewHolder(
            itemView: View,
            private val taskTitle: TextView,
            private val editButton: ImageButton,
            private val deleteButton: ImageButton
        ) : RecyclerView.ViewHolder(itemView) {
            fun bind(task: Task) {
                taskTitle.text = task.title
                editButton.setOnClickListener { onEditClick(task) }
                deleteButton.setOnClickListener { onDeleteClick(task) }
            }
        }
    }
}
